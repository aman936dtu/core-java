package com.training;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Products {
	
	

		public static  Items shirt =new Garments(101,"Shirt",2560,34,"nylon");
		public static Items pant =new Garments(102,"pant",6760,48,"polyster");
		public static Items trouser =new Garments(103,"trouser",4560,50,"mixed-silk");
		
		public static Items cake =new Edible(111,"vanila cake",360,LocalDate.of(2020, 03, 15),LocalDate.of(2021, 03, 15),"non-veg");
		public static Items chocolate =new Edible(112,"cadberry",660,LocalDate.of(2019, 02, 15),LocalDate.of(2021, 05, 25),"veg");
		public static Items pizza =new Edible(113,"loaded-pizza",470,LocalDate.of(2020, 03, 15),LocalDate.of(2020, 03, 25),"non-veg");
	
		 
	}

			
			
			
			
		
	
	
	
	


