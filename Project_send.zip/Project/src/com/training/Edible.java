package com.training;

import java.time.*;

public class Edible extends Items{
	private LocalDate dateofmanufacture;
	private LocalDate dateofxepirydate;
	private String foodtype;
	public Edible(int itemcode, String itemname, int unitprice, LocalDate dateofmanufacture, LocalDate dateofxepirydate,
			String foodtype) {
		super(itemcode, itemname, unitprice);
		this.dateofmanufacture = dateofmanufacture;
		this.dateofxepirydate = dateofxepirydate;
		this.foodtype = foodtype;
	}
	public LocalDate getDateofmanufacture() {
		return dateofmanufacture;
	}
	public void setDateofmanufacture(LocalDate dateofmanufacture) {
		this.dateofmanufacture = dateofmanufacture;
	}
	public LocalDate getDateofxepirydate() {
		return dateofxepirydate;
	}
	public void setDateofxepirydate(LocalDate dateofxepirydate) {
		this.dateofxepirydate = dateofxepirydate;
	}
	public String getFoodtype() {
		return foodtype;
	}
	public void setFoodtype(String foodtype) {
		this.foodtype = foodtype;
	}
	
	
	
	
	
	
	
	
	
}
