package com.training;

import java.sql.Date;
import java.time.LocalDate;

public class Garments extends Items{
	private int size;
	private String Material;
	public Garments(int itemcode, String itemname, int unitprice, int size, String material) {
		super(itemcode, itemname, unitprice);
		this.size = size;
		Material = material;
	}
	
	
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	public String getMaterial() {
		return Material;
	}
	public void setMaterial(String material) {
		Material = material;
	}
	
	
	

}
