package com.training;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;



public class Database {
	
	private Connection connection ;

	public Database(Connection connection) {
		super();
		this.connection = connection;
	}
	
	
	public boolean add(Items elem,int quant) {
		boolean result=false;
		if(elem instanceof Garments ) {		
		String sql ="insert into Garments values(?,?,?,?)";
		try (PreparedStatement  pstmt = connection.prepareStatement(sql);){
			pstmt.setString(1, elem.getItemname());
			pstmt.setInt(2, elem.getUnitprice());
			pstmt.setInt(3, quant);
			pstmt.setInt(4,(elem.getUnitprice()*quant));
			pstmt.executeUpdate();
			result=true;
			
		} catch(SQLException e) {
			e.printStackTrace();
		}}
		
		
		if(elem instanceof Edible) {		
			String sql2 ="insert into Edible values(?,?,?,?)";
			try (PreparedStatement  pstmt = connection.prepareStatement(sql2);){
				pstmt.setString(1, elem.getItemname());
				pstmt.setInt(2, elem.getUnitprice());
				pstmt.setInt(3, quant);
				pstmt.setInt(4,(elem.getUnitprice()*quant));
				pstmt.executeUpdate();
				result=true;
				
			} catch(SQLException e) {
				e.printStackTrace();
			}}
		
		if(elem instanceof Electronics) {		
			String sql3 ="insert into Electronics values(?,?,?,?)";
			try (PreparedStatement  pstmt = connection.prepareStatement(sql3);){
				pstmt.setString(1, elem.getItemname());
				pstmt.setInt(2, elem.getUnitprice());
				pstmt.setInt(3, quant);
				pstmt.setInt(4,(elem.getUnitprice()*quant));
				pstmt.executeUpdate();
				result=true;
				
			} catch(SQLException e) {
				e.printStackTrace();
			}}
		return result;	}
	
	 public  void billofgarments()  {
	    String query = "select * from Garments";
	    int ct=0;
	    int sno =0;
	    try (Statement stmt = connection.createStatement()) {
	      ResultSet rs = stmt.executeQuery(query);
	      System.out.println( "SI.No"+"  "+ "ItemName" + "  " + "UnitPrice" + "  " + "Quantity" +
                  "  " + "Amount");
	      while (rs.next()) {
	        String ItemName = rs.getString("ItemName");
	        int UnitPrice = rs.getInt("UnitPrice");
	        int Quantity = rs.getInt("Quantity");
	        int Amount = rs.getInt("Amount");
	        ct =ct + Amount;
	        sno =sno +1;
	        System.out.println( sno + "      "+ ItemName + "       " + UnitPrice + "        " + Quantity +
	                           "        " + Amount);
	      }
	      System.out.println("Total === "+ ct);
	    } catch (SQLException e) {
	       e.printStackTrace();
	    }
	  }
	
	 public  void billofedible() throws SQLException {
		    String query = "select * from Edible";
		    int ct=0;
		    int sno =0;
		    try (Statement stmt = connection.createStatement()) {
		      ResultSet rs = stmt.executeQuery(query);
		      System.out.println( "SI.No"+"  "+ "ItemName" + "  " + "UnitPrice" + "  " + "Quantity" +
	                  "  " + "Amount");
		      while (rs.next()) {
		        String ItemName = rs.getString("ItemName");
		        int UnitPrice = rs.getInt("UnitPrice");
		        int Quantity = rs.getInt("Quantity"); 
		        int Amount = rs.getInt("Amount");
		        ct =ct + Amount;
		        sno =sno +1;
		        System.out.println( sno + "      "+ ItemName + "       " + UnitPrice + "        " + Quantity +
		                           "        " + Amount);
		      }
		      System.out.println("Total === "+ ct);
		    } catch (SQLException e) {
		       e.printStackTrace();
		    }
		  }
	
	
	 
	 public  void billofelectronics()  {
		    String query = "select * from Electronics";
		    int ct=0;
		    int sno =0;
		    try (Statement stmt = connection.createStatement()) {
		      ResultSet rs = stmt.executeQuery(query);
		      System.out.println( "SI.No"+"  "+ "ItemName" + "  " + "UnitPrice" + "  " + "Quantity" +
	                  "  " + "Amount");
		      while (rs.next()) {
		        String ItemName = rs.getString("ItemName");
		        int UnitPrice = rs.getInt("UnitPrice");
		        int Quantity = rs.getInt("Quantity"); 
		        int Amount = rs.getInt("Amount");
		        ct =ct + Amount;
		        sno =sno +1;
		        System.out.println( sno + "      "+ ItemName + "       " + UnitPrice + "        " + Quantity +
		                           "        " + Amount);
		      }
		      System.out.println("Total === "+ ct);
		    } catch (SQLException e) {
		       e.printStackTrace();
		    }
		  }
	
	   public void topgarments() {
		int i=1;
		String sql = "select ItemName,Quantity from Garments order by Quantity DESC" ;
		System.out.println("SI.No"+"    "+"ItemName"+"    "+"Quantity");
		try (Statement stmt = connection.createStatement()){
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()){
		         String name  = rs.getString("ItemName");
		         int quant = rs.getInt("Quantity");
		         if (i==4) {
		        	 break;
		         }
		         System.out.println(i + "        "+ name + "        "+ quant);
		         i=i+1;
		         
		         }
		} catch (SQLException e) {
			//System.out.println("problem with connection");
			e.printStackTrace();}	
	}
	
}
