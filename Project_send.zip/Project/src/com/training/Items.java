package com.training;

public class Items {
	private int itemcode;
	private String itemname;
	private int unitprice;
	public Items(int itemcode, String itemname, int unitprice) {
		super();
		this.itemcode = itemcode;
		this.itemname = itemname;
		this.unitprice = unitprice;
	}
	public int getItemcode() {
		return itemcode;
	}
	public void setItemcode(int itemcode) {
		this.itemcode = itemcode;
	}
	public String getItemname() {
		return itemname;
	}
	public void setItemname(String itemname) {
		this.itemname = itemname;
	}
	public int getUnitprice() {
		return unitprice;
	}
	public void setUnitprice(int unitprice) {
		this.unitprice = unitprice;
	}
	

}
