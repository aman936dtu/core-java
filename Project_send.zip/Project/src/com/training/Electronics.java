package com.training;

public class Electronics extends Items{
	private int size;
	private String warranty;
	private String electricwattage;
	public Electronics(int itemcode, String itemname, int unitprice, int size, String warranty,
			String electricwattage) {
		super(itemcode, itemname, unitprice);
		this.size = size;
		this.warranty = warranty;
		this.electricwattage = electricwattage;
	}
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	public String getWarranty() {
		return warranty;
	}
	public void setWarranty(String warranty) {
		this.warranty = warranty;
	}
	public String getElectricwattage() {
		return electricwattage;
	}
	public void setElectricwattage(String electricwattage) {
		this.electricwattage = electricwattage;
	}
	
	
	
	
	
	
	
}
