package com.training;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;
import com.training.Products;
import com.training.ConnectionUtils;

public class shop {
	
	public static void main(String[] args) throws IOException {
	
		
		Connection connection =ConnectionUtils.getMysqlConnection();
		Database service =new Database(connection);
	//	System.out.println(ConnectionUtils.getpropasarray());
		service.add(Products.trouser,8);
		service.billofgarments();
		service.topgarments();
		
	
	
	
	
	}}
