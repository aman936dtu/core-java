package com.training;

import java.sql.*;

import java.util.Properties;

import javax.sql.DataSource;



import java.io.*;
public class ConnectionUtils {
	public static Connection getMysqlConnection() {
		Connection connection=null;
		try {
			String[] values = getpropasarray() ;
			connection = DriverManager.getConnection(values[0],values[2],values[1]);
		} catch(IOException |SQLException e) {
			e.printStackTrace();
			
		}
	
		return connection;
		}
	
	public static String[] getpropasarray() throws IOException{

		String filename ="resources/DBConnections.properties";
		
		InputStream stream = ConnectionUtils.class.getClassLoader().getResourceAsStream(filename);
		System.out.println(stream);
		Properties props =new Properties();
		System.out.println(props);
		props.load(stream);
		
		String Url = props.getProperty("database.Url");
		String passWord = props.getProperty("database.passWord");
		String userName = props.getProperty("database.userName");
		return new String[] {Url,passWord,userName};
	}
		
		
	
		
	}
	

